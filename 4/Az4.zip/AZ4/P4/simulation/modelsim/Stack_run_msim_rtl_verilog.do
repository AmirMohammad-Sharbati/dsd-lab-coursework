transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -vlog01compat -work work +incdir+E:/university/fifth_task/DSDLab/P4 {E:/university/fifth_task/DSDLab/P4/stack.v}

vlog -vlog01compat -work work +incdir+E:/university/fifth_task/DSDLab/P4 {E:/university/fifth_task/DSDLab/P4/tb.v}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cycloneii_ver -L rtl_work -L work -voptargs="+acc"  tb

add wave *
view structure
view signals
run -all

module stack (
    input wire Clk,
    input wire RstN,
    input wire [3:0] Data_In,
    input wire Push,
    input wire Pop,
    output reg [3:0] Data_out,
    output wire [6:0] hex,
    output reg Full, //Full = 1 indicates that stack is Full
    output reg Empty //Empty = 0 indicates that stack is empty
);
    reg [3:0] stack_instance[7:0];
    reg [3:0] pointer;
    
    assign hex[0] = (Data_out == 4'd1|| Data_out == 4'd4 || Data_out == 4'd11 || Data_out == 4'd13);
    assign hex[1] = (Data_out == 4'd5 || Data_out == 4'd6 || Data_out == 4'd11 || Data_out == 4'd14 || Data_out == 4'd15);
    assign hex[2] = (Data_out == 4'd2 || Data_out == 4'd12 || Data_out == 4'd14 || Data_out == 4'd15);
    assign hex[3] = (Data_out == 4'd1 || Data_out == 4'd4 || Data_out == 4'd7 || Data_out == 4'd9 || Data_out == 4'd10 || Data_out == 4'd15);
    assign hex[4] = (Data_out == 4'd1 || Data_out == 4'd3 || Data_out == 4'd4 || Data_out == 4'd5 || Data_out == 4'd7 || Data_out == 4'd9);
    assign hex[5] = (Data_out == 4'd1 || Data_out == 4'd2 || Data_out == 4'd3 || Data_out == 4'd7 || Data_out == 4'd13);
    assign hex[6] = (Data_out == 4'd0 || Data_out == 4'd1 || Data_out == 4'd7 || Data_out == 4'd12);

    always @(posedge Clk, negedge RstN) begin
        if(!RstN) begin
            Empty <= 1'b0;
            Full <= 1'b0;
            pointer <= 4'b0;
            Data_out <= 4'b0;
        end else if(Push && !Full) begin
                stack_instance[pointer] <= Data_In;
                pointer <= pointer + 1;
                Full <= (pointer == 4'd7);
                Empty <= 1'b1;
        end else if(Pop && Empty) begin
                pointer <= pointer - 1;
                Data_out <= stack_instance[pointer-1];
                Empty <= !(pointer == 4'd1);
                Full <= 1'b0;
            end
        end        
endmodule


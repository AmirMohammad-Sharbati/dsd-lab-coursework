library verilog;
use verilog.vl_types.all;
entity Incubator is
    port(
        RstN            : in     vl_logic;
        Clk             : in     vl_logic;
        temp            : in     vl_logic_vector(7 downto 0);
        is_heater_on    : out    vl_logic;
        cooler_RPS      : out    vl_logic_vector(3 downto 0)
    );
end Incubator;

-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.0.1 Build 232 06/12/2013 Service Pack 1 SJ Web Edition"

-- DATE "11/19/2025 20:16:30"

-- 
-- Device: Altera EP2C35F672C6 Package FBGA672
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY CYCLONEII;
LIBRARY IEEE;
USE CYCLONEII.CYCLONEII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	Incubator IS
    PORT (
	RstN : IN std_logic;
	Clk : IN std_logic;
	temp : IN std_logic_vector(7 DOWNTO 0);
	is_heater_on : OUT std_logic;
	cooler_RPS : OUT std_logic_vector(3 DOWNTO 0)
	);
END Incubator;

-- Design Ports Information
-- is_heater_on	=>  Location: PIN_D14,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 24mA
-- cooler_RPS[0]	=>  Location: PIN_H8,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 24mA
-- cooler_RPS[1]	=>  Location: PIN_G14,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 24mA
-- cooler_RPS[2]	=>  Location: PIN_F13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 24mA
-- cooler_RPS[3]	=>  Location: PIN_G13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 24mA
-- temp[7]	=>  Location: PIN_C13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- temp[5]	=>  Location: PIN_D13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- temp[6]	=>  Location: PIN_F14,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- temp[0]	=>  Location: PIN_C16,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- temp[3]	=>  Location: PIN_B15,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- temp[1]	=>  Location: PIN_B16,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- temp[2]	=>  Location: PIN_C15,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- temp[4]	=>  Location: PIN_A14,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- Clk	=>  Location: PIN_P2,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
-- RstN	=>  Location: PIN_P1,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default


ARCHITECTURE structure OF Incubator IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_RstN : std_logic;
SIGNAL ww_Clk : std_logic;
SIGNAL ww_temp : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_is_heater_on : std_logic;
SIGNAL ww_cooler_RPS : std_logic_vector(3 DOWNTO 0);
SIGNAL \Clk~clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \RstN~clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \LessThan7~1_combout\ : std_logic;
SIGNAL \always0~7_combout\ : std_logic;
SIGNAL \LessThan3~3_combout\ : std_logic;
SIGNAL \LessThan4~0_combout\ : std_logic;
SIGNAL \always0~11_combout\ : std_logic;
SIGNAL \LessThan1~0_combout\ : std_logic;
SIGNAL \state~20_combout\ : std_logic;
SIGNAL \LessThan3~5_combout\ : std_logic;
SIGNAL \Clk~combout\ : std_logic;
SIGNAL \Clk~clkctrl_outclk\ : std_logic;
SIGNAL \LessThan7~0_combout\ : std_logic;
SIGNAL \LessThan3~2_combout\ : std_logic;
SIGNAL \LessThan0~0_combout\ : std_logic;
SIGNAL \LessThan4~1_combout\ : std_logic;
SIGNAL \always0~8_combout\ : std_logic;
SIGNAL \LessThan6~0_combout\ : std_logic;
SIGNAL \state~15_combout\ : std_logic;
SIGNAL \LessThan3~4_combout\ : std_logic;
SIGNAL \always0~9_combout\ : std_logic;
SIGNAL \state~25_combout\ : std_logic;
SIGNAL \RstN~combout\ : std_logic;
SIGNAL \RstN~clkctrl_outclk\ : std_logic;
SIGNAL \state.011~regout\ : std_logic;
SIGNAL \always0~6_combout\ : std_logic;
SIGNAL \state~29_combout\ : std_logic;
SIGNAL \state~17_combout\ : std_logic;
SIGNAL \state~18_combout\ : std_logic;
SIGNAL \state~22_combout\ : std_logic;
SIGNAL \state.100~0_combout\ : std_logic;
SIGNAL \state.100~regout\ : std_logic;
SIGNAL \always0~12_combout\ : std_logic;
SIGNAL \state~19_combout\ : std_logic;
SIGNAL \state~21_combout\ : std_logic;
SIGNAL \state~23_combout\ : std_logic;
SIGNAL \state~28_combout\ : std_logic;
SIGNAL \state.010~regout\ : std_logic;
SIGNAL \always0~10_combout\ : std_logic;
SIGNAL \always0~13_combout\ : std_logic;
SIGNAL \state~26_combout\ : std_logic;
SIGNAL \state~27_combout\ : std_logic;
SIGNAL \state.001~regout\ : std_logic;
SIGNAL \state~16_combout\ : std_logic;
SIGNAL \state~30_combout\ : std_logic;
SIGNAL \state~24_combout\ : std_logic;
SIGNAL \state.000~regout\ : std_logic;
SIGNAL \always0~5_combout\ : std_logic;
SIGNAL \is_heater_on~0_combout\ : std_logic;
SIGNAL \is_heater_on~1_combout\ : std_logic;
SIGNAL \is_heater_on~2_combout\ : std_logic;
SIGNAL \is_heater_on~reg0_regout\ : std_logic;
SIGNAL \cooler_RPS[1]~1_combout\ : std_logic;
SIGNAL \cooler_RPS[1]~0_combout\ : std_logic;
SIGNAL \cooler_RPS[1]~2_combout\ : std_logic;
SIGNAL \cooler_RPS[1]~3_combout\ : std_logic;
SIGNAL \cooler_RPS[1]~reg0_regout\ : std_logic;
SIGNAL \always0~14_combout\ : std_logic;
SIGNAL \cooler_RPS~4_combout\ : std_logic;
SIGNAL \cooler_RPS~5_combout\ : std_logic;
SIGNAL \cooler_RPS[2]~reg0_regout\ : std_logic;
SIGNAL \cooler_RPS[3]~reg0_regout\ : std_logic;
SIGNAL \temp~combout\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \ALT_INV_RstN~clkctrl_outclk\ : std_logic;

BEGIN

ww_RstN <= RstN;
ww_Clk <= Clk;
ww_temp <= temp;
is_heater_on <= ww_is_heater_on;
cooler_RPS <= ww_cooler_RPS;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\Clk~clkctrl_INCLK_bus\ <= (gnd & gnd & gnd & \Clk~combout\);

\RstN~clkctrl_INCLK_bus\ <= (gnd & gnd & gnd & \RstN~combout\);
\ALT_INV_RstN~clkctrl_outclk\ <= NOT \RstN~clkctrl_outclk\;

-- Location: LCCOMB_X37_Y32_N26
\LessThan7~1\ : cycloneii_lcell_comb
-- Equation(s):
-- \LessThan7~1_combout\ = (\temp~combout\(3) & ((\temp~combout\(1)) # ((\temp~combout\(0)) # (\temp~combout\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \temp~combout\(3),
	datab => \temp~combout\(1),
	datac => \temp~combout\(0),
	datad => \temp~combout\(2),
	combout => \LessThan7~1_combout\);

-- Location: LCCOMB_X37_Y32_N18
\always0~7\ : cycloneii_lcell_comb
-- Equation(s):
-- \always0~7_combout\ = (!\temp~combout\(6) & (((!\LessThan7~1_combout\ & !\temp~combout\(4))) # (!\temp~combout\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000011111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan7~1_combout\,
	datab => \temp~combout\(4),
	datac => \temp~combout\(5),
	datad => \temp~combout\(6),
	combout => \always0~7_combout\);

-- Location: LCCOMB_X37_Y32_N4
\LessThan3~3\ : cycloneii_lcell_comb
-- Equation(s):
-- \LessThan3~3_combout\ = (\temp~combout\(3) & (\temp~combout\(1) & (\temp~combout\(5) & \temp~combout\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \temp~combout\(3),
	datab => \temp~combout\(1),
	datac => \temp~combout\(5),
	datad => \temp~combout\(2),
	combout => \LessThan3~3_combout\);

-- Location: LCCOMB_X37_Y32_N20
\LessThan4~0\ : cycloneii_lcell_comb
-- Equation(s):
-- \LessThan4~0_combout\ = (!\temp~combout\(3) & (!\temp~combout\(4) & !\temp~combout\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \temp~combout\(3),
	datac => \temp~combout\(4),
	datad => \temp~combout\(2),
	combout => \LessThan4~0_combout\);

-- Location: LCCOMB_X37_Y32_N28
\always0~11\ : cycloneii_lcell_comb
-- Equation(s):
-- \always0~11_combout\ = (\temp~combout\(5)) # ((\temp~combout\(4) & (\temp~combout\(0) & \LessThan3~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \temp~combout\(5),
	datab => \temp~combout\(4),
	datac => \temp~combout\(0),
	datad => \LessThan3~2_combout\,
	combout => \always0~11_combout\);

-- Location: LCCOMB_X37_Y32_N2
\LessThan1~0\ : cycloneii_lcell_comb
-- Equation(s):
-- \LessThan1~0_combout\ = (\temp~combout\(5) & ((\temp~combout\(3)) # ((\temp~combout\(4)) # (\temp~combout\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \temp~combout\(3),
	datab => \temp~combout\(4),
	datac => \temp~combout\(5),
	datad => \temp~combout\(2),
	combout => \LessThan1~0_combout\);

-- Location: LCCOMB_X37_Y32_N10
\state~20\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~20_combout\ = (\state~17_combout\ & ((\temp~combout\(5) & (\LessThan4~0_combout\)) # (!\temp~combout\(5) & ((!\LessThan0~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000010001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan4~0_combout\,
	datab => \state~17_combout\,
	datac => \temp~combout\(5),
	datad => \LessThan0~0_combout\,
	combout => \state~20_combout\);

-- Location: LCCOMB_X37_Y32_N16
\LessThan3~5\ : cycloneii_lcell_comb
-- Equation(s):
-- \LessThan3~5_combout\ = (\LessThan3~3_combout\) # ((\temp~combout\(6)) # ((\temp~combout\(5) & \temp~combout\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \temp~combout\(5),
	datab => \temp~combout\(4),
	datac => \LessThan3~3_combout\,
	datad => \temp~combout\(6),
	combout => \LessThan3~5_combout\);

-- Location: PIN_B15,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
\temp[3]~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "input",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => GND,
	padio => ww_temp(3),
	combout => \temp~combout\(3));

-- Location: PIN_P2,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
\Clk~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "input",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => GND,
	padio => ww_Clk,
	combout => \Clk~combout\);

-- Location: CLKCTRL_G3
\Clk~clkctrl\ : cycloneii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \Clk~clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \Clk~clkctrl_outclk\);

-- Location: PIN_D13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
\temp[5]~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "input",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => GND,
	padio => ww_temp(5),
	combout => \temp~combout\(5));

-- Location: PIN_F14,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
\temp[6]~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "input",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => GND,
	padio => ww_temp(6),
	combout => \temp~combout\(6));

-- Location: LCCOMB_X37_Y32_N24
\LessThan7~0\ : cycloneii_lcell_comb
-- Equation(s):
-- \LessThan7~0_combout\ = (!\temp~combout\(5) & !\temp~combout\(6))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \temp~combout\(5),
	datad => \temp~combout\(6),
	combout => \LessThan7~0_combout\);

-- Location: PIN_A14,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
\temp[4]~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "input",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => GND,
	padio => ww_temp(4),
	combout => \temp~combout\(4));

-- Location: PIN_C16,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
\temp[0]~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "input",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => GND,
	padio => ww_temp(0),
	combout => \temp~combout\(0));

-- Location: PIN_B16,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
\temp[1]~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "input",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => GND,
	padio => ww_temp(1),
	combout => \temp~combout\(1));

-- Location: PIN_C15,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
\temp[2]~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "input",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => GND,
	padio => ww_temp(2),
	combout => \temp~combout\(2));

-- Location: LCCOMB_X37_Y32_N22
\LessThan3~2\ : cycloneii_lcell_comb
-- Equation(s):
-- \LessThan3~2_combout\ = (\temp~combout\(3) & (\temp~combout\(1) & \temp~combout\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \temp~combout\(3),
	datac => \temp~combout\(1),
	datad => \temp~combout\(2),
	combout => \LessThan3~2_combout\);

-- Location: LCCOMB_X37_Y32_N12
\LessThan0~0\ : cycloneii_lcell_comb
-- Equation(s):
-- \LessThan0~0_combout\ = (!\temp~combout\(4) & ((!\LessThan3~2_combout\) # (!\temp~combout\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \temp~combout\(4),
	datac => \temp~combout\(0),
	datad => \LessThan3~2_combout\,
	combout => \LessThan0~0_combout\);

-- Location: LCCOMB_X37_Y32_N30
\LessThan4~1\ : cycloneii_lcell_comb
-- Equation(s):
-- \LessThan4~1_combout\ = ((\LessThan4~0_combout\ & ((!\temp~combout\(1)) # (!\temp~combout\(0))))) # (!\temp~combout\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010101011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan4~0_combout\,
	datab => \temp~combout\(0),
	datac => \temp~combout\(1),
	datad => \temp~combout\(5),
	combout => \LessThan4~1_combout\);

-- Location: PIN_C13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
\temp[7]~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "input",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => GND,
	padio => ww_temp(7),
	combout => \temp~combout\(7));

-- Location: LCCOMB_X35_Y32_N22
\always0~8\ : cycloneii_lcell_comb
-- Equation(s):
-- \always0~8_combout\ = (!\always0~7_combout\ & (!\temp~combout\(7) & \state.001~regout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \always0~7_combout\,
	datac => \temp~combout\(7),
	datad => \state.001~regout\,
	combout => \always0~8_combout\);

-- Location: LCCOMB_X37_Y32_N8
\LessThan6~0\ : cycloneii_lcell_comb
-- Equation(s):
-- \LessThan6~0_combout\ = (!\temp~combout\(6) & (((!\temp~combout\(3) & !\temp~combout\(4))) # (!\temp~combout\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000011111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \temp~combout\(3),
	datab => \temp~combout\(4),
	datac => \temp~combout\(5),
	datad => \temp~combout\(6),
	combout => \LessThan6~0_combout\);

-- Location: LCCOMB_X36_Y32_N12
\state~15\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~15_combout\ = (!\temp~combout\(7) & (((\LessThan7~1_combout\ & \temp~combout\(4))) # (!\LessThan7~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan7~1_combout\,
	datab => \temp~combout\(4),
	datac => \temp~combout\(7),
	datad => \LessThan7~0_combout\,
	combout => \state~15_combout\);

-- Location: LCCOMB_X37_Y32_N14
\LessThan3~4\ : cycloneii_lcell_comb
-- Equation(s):
-- \LessThan3~4_combout\ = (\temp~combout\(6)) # ((\temp~combout\(4) & \temp~combout\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \temp~combout\(4),
	datac => \temp~combout\(5),
	datad => \temp~combout\(6),
	combout => \LessThan3~4_combout\);

-- Location: LCCOMB_X36_Y32_N20
\always0~9\ : cycloneii_lcell_comb
-- Equation(s):
-- \always0~9_combout\ = (!\temp~combout\(7) & (\state.010~regout\ & ((\LessThan3~3_combout\) # (\LessThan3~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan3~3_combout\,
	datab => \LessThan3~4_combout\,
	datac => \temp~combout\(7),
	datad => \state.010~regout\,
	combout => \always0~9_combout\);

-- Location: LCCOMB_X35_Y32_N8
\state~25\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~25_combout\ = (\state~23_combout\ & (((\state.011~regout\)))) # (!\state~23_combout\ & (\always0~9_combout\ & ((!\always0~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state~23_combout\,
	datab => \always0~9_combout\,
	datac => \state.011~regout\,
	datad => \always0~5_combout\,
	combout => \state~25_combout\);

-- Location: PIN_P1,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
\RstN~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "input",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => GND,
	padio => ww_RstN,
	combout => \RstN~combout\);

-- Location: CLKCTRL_G1
\RstN~clkctrl\ : cycloneii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \RstN~clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \RstN~clkctrl_outclk\);

-- Location: LCFF_X35_Y32_N9
\state.011\ : cycloneii_lcell_ff
PORT MAP (
	clk => \Clk~clkctrl_outclk\,
	datain => \state~25_combout\,
	aclr => \ALT_INV_RstN~clkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \state.011~regout\);

-- Location: LCCOMB_X35_Y32_N6
\always0~6\ : cycloneii_lcell_comb
-- Equation(s):
-- \always0~6_combout\ = (\LessThan6~0_combout\ & (\state~15_combout\ & \state.011~regout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \LessThan6~0_combout\,
	datac => \state~15_combout\,
	datad => \state.011~regout\,
	combout => \always0~6_combout\);

-- Location: LCCOMB_X36_Y32_N14
\state~29\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~29_combout\ = (\state~15_combout\ & ((\always0~8_combout\) # ((\always0~6_combout\)))) # (!\state~15_combout\ & (!\state.001~regout\ & ((\always0~8_combout\) # (\always0~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state~15_combout\,
	datab => \always0~8_combout\,
	datac => \always0~6_combout\,
	datad => \state.001~regout\,
	combout => \state~29_combout\);

-- Location: LCCOMB_X36_Y32_N28
\state~17\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~17_combout\ = (!\temp~combout\(6) & !\temp~combout\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \temp~combout\(6),
	datac => \temp~combout\(7),
	combout => \state~17_combout\);

-- Location: LCCOMB_X37_Y32_N0
\state~18\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~18_combout\ = (\state~17_combout\ & ((\LessThan7~1_combout\ & (\temp~combout\(4) & !\temp~combout\(5))) # (!\LessThan7~1_combout\ & (!\temp~combout\(4) & \temp~combout\(5)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan7~1_combout\,
	datab => \temp~combout\(4),
	datac => \temp~combout\(5),
	datad => \state~17_combout\,
	combout => \state~18_combout\);

-- Location: LCCOMB_X36_Y32_N26
\state~22\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~22_combout\ = ((!\LessThan3~5_combout\ & (!\LessThan4~1_combout\ & !\temp~combout\(7)))) # (!\state.010~regout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan3~5_combout\,
	datab => \LessThan4~1_combout\,
	datac => \temp~combout\(7),
	datad => \state.010~regout\,
	combout => \state~22_combout\);

-- Location: LCCOMB_X35_Y32_N2
\state.100~0\ : cycloneii_lcell_comb
-- Equation(s):
-- \state.100~0_combout\ = (\state~23_combout\ & ((\state.100~regout\))) # (!\state~23_combout\ & (\always0~5_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \always0~5_combout\,
	datac => \state.100~regout\,
	datad => \state~23_combout\,
	combout => \state.100~0_combout\);

-- Location: LCFF_X35_Y32_N3
\state.100\ : cycloneii_lcell_ff
PORT MAP (
	clk => \Clk~clkctrl_outclk\,
	datain => \state.100~0_combout\,
	aclr => \ALT_INV_RstN~clkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \state.100~regout\);

-- Location: LCCOMB_X35_Y32_N4
\always0~12\ : cycloneii_lcell_comb
-- Equation(s):
-- \always0~12_combout\ = (!\temp~combout\(7) & (\state.100~regout\ & ((\always0~11_combout\) # (\temp~combout\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \always0~11_combout\,
	datab => \temp~combout\(6),
	datac => \temp~combout\(7),
	datad => \state.100~regout\,
	combout => \always0~12_combout\);

-- Location: LCCOMB_X35_Y32_N0
\state~19\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~19_combout\ = ((!\LessThan6~0_combout\ & \state~15_combout\)) # (!\state.011~regout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \LessThan6~0_combout\,
	datac => \state~15_combout\,
	datad => \state.011~regout\,
	combout => \state~19_combout\);

-- Location: LCCOMB_X35_Y32_N30
\state~21\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~21_combout\ = (!\always0~12_combout\ & (\state~19_combout\ & ((\state~20_combout\) # (\state.000~regout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state~20_combout\,
	datab => \state.000~regout\,
	datac => \always0~12_combout\,
	datad => \state~19_combout\,
	combout => \state~21_combout\);

-- Location: LCCOMB_X35_Y32_N16
\state~23\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~23_combout\ = (\state~22_combout\ & (\state~21_combout\ & ((\state~18_combout\) # (!\state.001~regout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state.001~regout\,
	datab => \state~18_combout\,
	datac => \state~22_combout\,
	datad => \state~21_combout\,
	combout => \state~23_combout\);

-- Location: LCCOMB_X36_Y32_N18
\state~28\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~28_combout\ = (\state~23_combout\ & (((\state.010~regout\)))) # (!\state~23_combout\ & (!\always0~5_combout\ & (\state~29_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \always0~5_combout\,
	datab => \state~29_combout\,
	datac => \state.010~regout\,
	datad => \state~23_combout\,
	combout => \state~28_combout\);

-- Location: LCFF_X36_Y32_N19
\state.010\ : cycloneii_lcell_ff
PORT MAP (
	clk => \Clk~clkctrl_outclk\,
	datain => \state~28_combout\,
	aclr => \ALT_INV_RstN~clkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \state.010~regout\);

-- Location: LCCOMB_X36_Y32_N16
\always0~10\ : cycloneii_lcell_comb
-- Equation(s):
-- \always0~10_combout\ = (\state~15_combout\ & (\LessThan4~1_combout\ & (!\temp~combout\(6) & \state.010~regout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state~15_combout\,
	datab => \LessThan4~1_combout\,
	datac => \temp~combout\(6),
	datad => \state.010~regout\,
	combout => \always0~10_combout\);

-- Location: LCCOMB_X36_Y32_N6
\always0~13\ : cycloneii_lcell_comb
-- Equation(s):
-- \always0~13_combout\ = (!\temp~combout\(7) & (!\state.000~regout\ & ((\LessThan1~0_combout\) # (\temp~combout\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan1~0_combout\,
	datab => \temp~combout\(6),
	datac => \temp~combout\(7),
	datad => \state.000~regout\,
	combout => \always0~13_combout\);

-- Location: LCCOMB_X36_Y32_N24
\state~26\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~26_combout\ = (\always0~13_combout\) # ((!\always0~9_combout\ & \always0~10_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \always0~9_combout\,
	datac => \always0~10_combout\,
	datad => \always0~13_combout\,
	combout => \state~26_combout\);

-- Location: LCCOMB_X35_Y32_N12
\state~27\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~27_combout\ = (\state~23_combout\ & (((\state.001~regout\)))) # (!\state~23_combout\ & (!\always0~5_combout\ & ((\state~26_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state~23_combout\,
	datab => \always0~5_combout\,
	datac => \state.001~regout\,
	datad => \state~26_combout\,
	combout => \state~27_combout\);

-- Location: LCFF_X35_Y32_N13
\state.001\ : cycloneii_lcell_ff
PORT MAP (
	clk => \Clk~clkctrl_outclk\,
	datain => \state~27_combout\,
	aclr => \ALT_INV_RstN~clkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \state.001~regout\);

-- Location: LCCOMB_X35_Y32_N20
\state~16\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~16_combout\ = (!\always0~6_combout\ & (!\always0~8_combout\ & (!\always0~10_combout\ & !\always0~9_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \always0~6_combout\,
	datab => \always0~8_combout\,
	datac => \always0~10_combout\,
	datad => \always0~9_combout\,
	combout => \state~16_combout\);

-- Location: LCCOMB_X35_Y32_N10
\state~30\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~30_combout\ = (!\always0~13_combout\ & ((\state~16_combout\) # ((!\state~15_combout\ & \state.001~regout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state~15_combout\,
	datab => \state.001~regout\,
	datac => \state~16_combout\,
	datad => \always0~13_combout\,
	combout => \state~30_combout\);

-- Location: LCCOMB_X35_Y32_N26
\state~24\ : cycloneii_lcell_comb
-- Equation(s):
-- \state~24_combout\ = (\state~23_combout\ & (((\state.000~regout\)))) # (!\state~23_combout\ & ((\always0~5_combout\) # ((!\state~30_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110010011110101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state~23_combout\,
	datab => \always0~5_combout\,
	datac => \state.000~regout\,
	datad => \state~30_combout\,
	combout => \state~24_combout\);

-- Location: LCFF_X35_Y32_N27
\state.000\ : cycloneii_lcell_ff
PORT MAP (
	clk => \Clk~clkctrl_outclk\,
	datain => \state~24_combout\,
	aclr => \ALT_INV_RstN~clkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \state.000~regout\);

-- Location: LCCOMB_X36_Y32_N30
\always0~5\ : cycloneii_lcell_comb
-- Equation(s):
-- \always0~5_combout\ = (!\state.000~regout\ & ((\temp~combout\(7)) # ((\LessThan7~0_combout\ & \LessThan0~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \temp~combout\(7),
	datab => \LessThan7~0_combout\,
	datac => \LessThan0~0_combout\,
	datad => \state.000~regout\,
	combout => \always0~5_combout\);

-- Location: LCCOMB_X35_Y32_N18
\is_heater_on~0\ : cycloneii_lcell_comb
-- Equation(s):
-- \is_heater_on~0_combout\ = (\state.011~regout\) # ((\state.001~regout\) # (\state.010~regout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \state.011~regout\,
	datac => \state.001~regout\,
	datad => \state.010~regout\,
	combout => \is_heater_on~0_combout\);

-- Location: LCCOMB_X35_Y32_N24
\is_heater_on~1\ : cycloneii_lcell_comb
-- Equation(s):
-- \is_heater_on~1_combout\ = ((\always0~13_combout\) # ((!\state~15_combout\ & \is_heater_on~0_combout\))) # (!\always0~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state~15_combout\,
	datab => \is_heater_on~0_combout\,
	datac => \always0~12_combout\,
	datad => \always0~13_combout\,
	combout => \is_heater_on~1_combout\);

-- Location: LCCOMB_X35_Y32_N28
\is_heater_on~2\ : cycloneii_lcell_comb
-- Equation(s):
-- \is_heater_on~2_combout\ = (\always0~5_combout\) # ((\is_heater_on~reg0_regout\ & ((\is_heater_on~1_combout\) # (!\state~16_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011011100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state~16_combout\,
	datab => \always0~5_combout\,
	datac => \is_heater_on~reg0_regout\,
	datad => \is_heater_on~1_combout\,
	combout => \is_heater_on~2_combout\);

-- Location: LCFF_X35_Y32_N29
\is_heater_on~reg0\ : cycloneii_lcell_ff
PORT MAP (
	clk => \Clk~clkctrl_outclk\,
	datain => \is_heater_on~2_combout\,
	aclr => \ALT_INV_RstN~clkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \is_heater_on~reg0_regout\);

-- Location: LCCOMB_X36_Y32_N2
\cooler_RPS[1]~1\ : cycloneii_lcell_comb
-- Equation(s):
-- \cooler_RPS[1]~1_combout\ = (\LessThan3~5_combout\ & (((!\temp~combout\(6) & \LessThan4~1_combout\)) # (!\temp~combout\(7)))) # (!\LessThan3~5_combout\ & (!\temp~combout\(6) & ((\LessThan4~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011101100001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \LessThan3~5_combout\,
	datab => \temp~combout\(6),
	datac => \temp~combout\(7),
	datad => \LessThan4~1_combout\,
	combout => \cooler_RPS[1]~1_combout\);

-- Location: LCCOMB_X35_Y32_N14
\cooler_RPS[1]~0\ : cycloneii_lcell_comb
-- Equation(s):
-- \cooler_RPS[1]~0_combout\ = (\state~15_combout\ & ((\state~18_combout\) # ((!\state.001~regout\)))) # (!\state~15_combout\ & (!\state.011~regout\ & ((\state~18_combout\) # (!\state.001~regout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state~15_combout\,
	datab => \state~18_combout\,
	datac => \state.011~regout\,
	datad => \state.001~regout\,
	combout => \cooler_RPS[1]~0_combout\);

-- Location: LCCOMB_X36_Y32_N0
\cooler_RPS[1]~2\ : cycloneii_lcell_comb
-- Equation(s):
-- \cooler_RPS[1]~2_combout\ = (\cooler_RPS[1]~0_combout\ & (((\state~15_combout\ & !\cooler_RPS[1]~1_combout\)) # (!\state.010~regout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state~15_combout\,
	datab => \cooler_RPS[1]~1_combout\,
	datac => \state.010~regout\,
	datad => \cooler_RPS[1]~0_combout\,
	combout => \cooler_RPS[1]~2_combout\);

-- Location: LCCOMB_X36_Y32_N10
\cooler_RPS[1]~3\ : cycloneii_lcell_comb
-- Equation(s):
-- \cooler_RPS[1]~3_combout\ = (!\always0~5_combout\ & ((\always0~13_combout\) # ((\always0~6_combout\) # (!\cooler_RPS[1]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \always0~13_combout\,
	datab => \always0~5_combout\,
	datac => \always0~6_combout\,
	datad => \cooler_RPS[1]~2_combout\,
	combout => \cooler_RPS[1]~3_combout\);

-- Location: LCFF_X36_Y32_N5
\cooler_RPS[1]~reg0\ : cycloneii_lcell_ff
PORT MAP (
	clk => \Clk~clkctrl_outclk\,
	sdata => \state~29_combout\,
	aclr => \ALT_INV_RstN~clkctrl_outclk\,
	sload => VCC,
	ena => \cooler_RPS[1]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \cooler_RPS[1]~reg0_regout\);

-- Location: LCCOMB_X36_Y32_N4
\always0~14\ : cycloneii_lcell_comb
-- Equation(s):
-- \always0~14_combout\ = (!\state~15_combout\ & \state.001~regout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \state~15_combout\,
	datad => \state.001~regout\,
	combout => \always0~14_combout\);

-- Location: LCCOMB_X36_Y32_N8
\cooler_RPS~4\ : cycloneii_lcell_comb
-- Equation(s):
-- \cooler_RPS~4_combout\ = (!\always0~14_combout\ & (!\always0~9_combout\ & ((\always0~10_combout\) # (\always0~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \always0~10_combout\,
	datab => \always0~14_combout\,
	datac => \always0~9_combout\,
	datad => \always0~6_combout\,
	combout => \cooler_RPS~4_combout\);

-- Location: LCCOMB_X36_Y32_N22
\cooler_RPS~5\ : cycloneii_lcell_comb
-- Equation(s):
-- \cooler_RPS~5_combout\ = (\always0~13_combout\) # ((\cooler_RPS~4_combout\) # ((!\always0~14_combout\ & \always0~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101111111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \always0~13_combout\,
	datab => \always0~14_combout\,
	datac => \cooler_RPS~4_combout\,
	datad => \always0~8_combout\,
	combout => \cooler_RPS~5_combout\);

-- Location: LCFF_X36_Y32_N23
\cooler_RPS[2]~reg0\ : cycloneii_lcell_ff
PORT MAP (
	clk => \Clk~clkctrl_outclk\,
	datain => \cooler_RPS~5_combout\,
	aclr => \ALT_INV_RstN~clkctrl_outclk\,
	ena => \cooler_RPS[1]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \cooler_RPS[2]~reg0_regout\);

-- Location: LCFF_X36_Y32_N21
\cooler_RPS[3]~reg0\ : cycloneii_lcell_ff
PORT MAP (
	clk => \Clk~clkctrl_outclk\,
	datain => \always0~9_combout\,
	aclr => \ALT_INV_RstN~clkctrl_outclk\,
	ena => \cooler_RPS[1]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \cooler_RPS[3]~reg0_regout\);

-- Location: PIN_D14,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 24mA
\is_heater_on~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "output",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	datain => \is_heater_on~reg0_regout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => VCC,
	padio => ww_is_heater_on);

-- Location: PIN_H8,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 24mA
\cooler_RPS[0]~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "output",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	datain => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => VCC,
	padio => ww_cooler_RPS(0));

-- Location: PIN_G14,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 24mA
\cooler_RPS[1]~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "output",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	datain => \cooler_RPS[1]~reg0_regout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => VCC,
	padio => ww_cooler_RPS(1));

-- Location: PIN_F13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 24mA
\cooler_RPS[2]~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "output",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	datain => \cooler_RPS[2]~reg0_regout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => VCC,
	padio => ww_cooler_RPS(2));

-- Location: PIN_G13,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 24mA
\cooler_RPS[3]~I\ : cycloneii_io
-- pragma translate_off
GENERIC MAP (
	input_async_reset => "none",
	input_power_up => "low",
	input_register_mode => "none",
	input_sync_reset => "none",
	oe_async_reset => "none",
	oe_power_up => "low",
	oe_register_mode => "none",
	oe_sync_reset => "none",
	operation_mode => "output",
	output_async_reset => "none",
	output_power_up => "low",
	output_register_mode => "none",
	output_sync_reset => "none")
-- pragma translate_on
PORT MAP (
	datain => \cooler_RPS[3]~reg0_regout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	devoe => ww_devoe,
	oe => VCC,
	padio => ww_cooler_RPS(3));
END structure;



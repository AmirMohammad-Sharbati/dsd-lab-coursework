library verilog;
use verilog.vl_types.all;
entity div3 is
    port(
        isDivisible     : out    vl_logic;
        A0              : in     vl_logic_vector(3 downto 0);
        A2              : in     vl_logic_vector(3 downto 0);
        A1              : in     vl_logic_vector(3 downto 0);
        A3              : in     vl_logic_vector(3 downto 0)
    );
end div3;

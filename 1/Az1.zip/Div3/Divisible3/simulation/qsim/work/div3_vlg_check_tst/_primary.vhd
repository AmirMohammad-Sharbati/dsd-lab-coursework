library verilog;
use verilog.vl_types.all;
entity div3_vlg_check_tst is
    port(
        isDivisible     : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end div3_vlg_check_tst;

library verilog;
use verilog.vl_types.all;
entity div11_vlg_check_tst is
    port(
        isDivisible     : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end div11_vlg_check_tst;
